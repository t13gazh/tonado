import{l as o,a as r}from"../chunks/B8oKg3yz.js";export{o as load_css,r as start};
