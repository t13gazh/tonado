import{l as o,a as r}from"../chunks/Du5M64P8.js";export{o as load_css,r as start};
