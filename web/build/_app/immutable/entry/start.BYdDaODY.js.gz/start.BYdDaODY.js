import{l as o,a as r}from"../chunks/Dt0rT5Ce.js";export{o as load_css,r as start};
