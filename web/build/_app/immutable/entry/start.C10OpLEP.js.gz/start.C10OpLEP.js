import{l as o,a as r}from"../chunks/DHJSi6rk.js";export{o as load_css,r as start};
