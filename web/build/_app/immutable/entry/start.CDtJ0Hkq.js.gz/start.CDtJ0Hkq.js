import{l as o,a as r}from"../chunks/D0C4HCZI.js";export{o as load_css,r as start};
