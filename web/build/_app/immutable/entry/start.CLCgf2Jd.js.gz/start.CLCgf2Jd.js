import{l as o,a as r}from"../chunks/6eCxYYIG.js";export{o as load_css,r as start};
