import{l as o,a as r}from"../chunks/CLAmc6Tt.js";export{o as load_css,r as start};
