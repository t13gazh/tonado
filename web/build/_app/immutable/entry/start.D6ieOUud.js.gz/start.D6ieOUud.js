import{l as o,a as r}from"../chunks/BKQB91Nk.js";export{o as load_css,r as start};
