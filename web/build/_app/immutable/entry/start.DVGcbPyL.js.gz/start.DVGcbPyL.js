import{l as o,a as r}from"../chunks/CqV3e0MI.js";export{o as load_css,r as start};
