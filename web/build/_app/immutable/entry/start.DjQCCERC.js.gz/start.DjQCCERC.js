import{l as o,a as r}from"../chunks/Ck0-mzUR.js";export{o as load_css,r as start};
