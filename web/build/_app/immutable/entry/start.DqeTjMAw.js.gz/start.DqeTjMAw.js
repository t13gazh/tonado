import{l as o,a as r}from"../chunks/BJU2PQIS.js";export{o as load_css,r as start};
