import{l as o,a as r}from"../chunks/BO9Q-Dpw.js";export{o as load_css,r as start};
