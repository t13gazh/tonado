import{l as o,a as r}from"../chunks/B6NoOgfq.js";export{o as load_css,r as start};
