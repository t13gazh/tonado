import{l as o,a as r}from"../chunks/t4GbfmZe.js";export{o as load_css,r as start};
