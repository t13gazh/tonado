import{l as o,a as r}from"../chunks/BD8fbjWx.js";export{o as load_css,r as start};
