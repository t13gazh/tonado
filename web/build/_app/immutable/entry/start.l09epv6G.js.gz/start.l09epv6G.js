import{l as o,a as r}from"../chunks/BquhM_v_.js";export{o as load_css,r as start};
