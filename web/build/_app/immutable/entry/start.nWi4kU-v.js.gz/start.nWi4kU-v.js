import{l as o,a as r}from"../chunks/Daf4chBA.js";export{o as load_css,r as start};
